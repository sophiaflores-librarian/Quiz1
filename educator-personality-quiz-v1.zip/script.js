
const themes={Muppets:{A:'Kermit',B:'Sam Eagle',C:'Scooter',D:'Gonzo'},Barbie:{A:'Barbie',B:'President Barbie',C:'Weird Barbie',D:'Astronaut Barbie'},MOTU:{A:'Orko',B:'Man-at-Arms',C:'Teela',D:'He-Man'},Marvel:{A:'Spider-Man',B:'Captain America',C:'Black Panther',D:'Iron Man'}};
const qs=[
["When planning a lesson, what excites you most?",["Creating engaging activities","Organizing everything","Personalizing learning","Real-world connections"]],
["A student is struggling. You...",["Encourage them","Break it into steps","Talk privately","Try another strategy"]],
["Your classroom feels successful when...",["Everyone participates","Expectations are clear","Students feel supported","Students solve real problems"]],
["Colleagues describe you as...",["Energetic","Organized","Compassionate","Innovative"]],
["One extra hour...",["Design lessons","Improve routines","Build relationships","Learn something new"]]];
let theme=null,i=0,ans=[];const letters=['A','B','C','D'];const app=document.getElementById('app');
function menu(){app.innerHTML="<h2>Choose a Theme</h2>"+Object.keys(themes).map(t=>`<button onclick="pick('${t}')">${t}</button>`).join("");}
window.pick=t=>{theme=t;i=0;ans=[];show();}
function show(){let q=qs[i];app.innerHTML=`<h3>Question ${i+1} of ${qs.length}</h3><p>${q[0]}</p>`+q[1].map((x,n)=>`<button onclick="answer('${letters[n]}')">${x}</button>`).join("");}
window.answer=a=>{ans.push(a);i++;if(i<qs.length)show();else result();}
function result(){let c={A:0,B:0,C:0,D:0};ans.forEach(x=>c[x]++);let w='A';for(let k in c)if(c[k]>c[w])w=k;app.innerHTML=`<h2>You are ${themes[theme][w]}!</h2><p>Theme: ${theme}</p><p>Thanks for taking the quiz.</p><button onclick='menu()'>Play Again</button>`;}
menu();
