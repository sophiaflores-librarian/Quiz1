# Version 1

Upload all files to a GitHub repository and enable GitHub Pages.

Includes:
- Theme selection
- 5-question quiz
- Immediate results
- Muppets, Barbie, Masters of the Universe, Marvel
